﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace gorsel_final_odev
{
    public partial class uyeol : Form
    {
        public uyeol()
        {
            InitializeComponent();
        }

        veritabani vt = new veritabani();
        private void uyeol_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {


        }


        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (checkBox1.Checked)
                {
                    // bağlantıyı açalım
                    vt.mysqlbaglan.Open();
                    // ekleme komutunu tanımladım ve insert sorgusunu yazdım.
                    MySqlCommand ekle = new MySqlCommand("insert into uyeler (ad,soyad,tel,eposta,kadi,sifre) values ('" + tx_1.Text + "','" + tx_2.Text + "','" + tx_3.Text + "','" + tx_4.Text + "','" + tx_5.Text + "','" + tx_6.Text + "')", vt.mysqlbaglan);
                    // sorguyu çalıştırıyorum.
                    object sonuc = null;
                    sonuc = ekle.ExecuteNonQuery(); // sorgu çalıştı ve dönen değer objec türünden değişkene geçti eğer değişken boş değilse eklendi boşşsa eklenmedi.
                    if (sonuc != null)
                    {
                        MessageBox.Show("Sisteme başarıyla eklendi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    
                    else
                        MessageBox.Show("Sisteme eklenemedi.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    // bağlantıyı kapatalım
                    vt.mysqlbaglan.Close();
                }
                else
                {
                    MessageBox.Show("Şartarı kabul edin", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception HataYakala)
            {
                MessageBox.Show("Hata: " + HataYakala.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

    }
}
