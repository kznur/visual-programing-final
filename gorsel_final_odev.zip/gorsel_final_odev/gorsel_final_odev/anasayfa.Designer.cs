﻿namespace gorsel_final_odev
{
    partial class anasayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(anasayfa));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hAKKIMIZDAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pOPULEROTELLERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eRKENREZERVASYONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pOPULERTATİLBÖLGELERİToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alanyaOtelleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çeşmeOtelleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kıbrısOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uludağOtelleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sakaryaOtelleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kapadokyaOtelleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayvalıkOtelleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kuşadasıOtelleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iLETİŞİMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gİRİŞToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bULToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hAKKIMIZDAToolStripMenuItem,
            this.pOPULEROTELLERToolStripMenuItem,
            this.eRKENREZERVASYONToolStripMenuItem,
            this.pOPULERTATİLBÖLGELERİToolStripMenuItem,
            this.iLETİŞİMToolStripMenuItem,
            this.gİRİŞToolStripMenuItem,
            this.bULToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(973, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // hAKKIMIZDAToolStripMenuItem
            // 
            this.hAKKIMIZDAToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.hAKKIMIZDAToolStripMenuItem.Name = "hAKKIMIZDAToolStripMenuItem";
            this.hAKKIMIZDAToolStripMenuItem.Size = new System.Drawing.Size(165, 29);
            this.hAKKIMIZDAToolStripMenuItem.Text = "PREMIUM HOTEL";
            this.hAKKIMIZDAToolStripMenuItem.Click += new System.EventHandler(this.hAKKIMIZDAToolStripMenuItem_Click);
            // 
            // pOPULEROTELLERToolStripMenuItem
            // 
            this.pOPULEROTELLERToolStripMenuItem.Name = "pOPULEROTELLERToolStripMenuItem";
            this.pOPULEROTELLERToolStripMenuItem.Size = new System.Drawing.Size(90, 29);
            this.pOPULEROTELLERToolStripMenuItem.Text = "HAKKIMIZDA";
            this.pOPULEROTELLERToolStripMenuItem.Click += new System.EventHandler(this.pOPULEROTELLERToolStripMenuItem_Click);
            // 
            // eRKENREZERVASYONToolStripMenuItem
            // 
            this.eRKENREZERVASYONToolStripMenuItem.Name = "eRKENREZERVASYONToolStripMenuItem";
            this.eRKENREZERVASYONToolStripMenuItem.Size = new System.Drawing.Size(145, 29);
            this.eRKENREZERVASYONToolStripMenuItem.Text = "SIK SORULAN SORULAR";
            this.eRKENREZERVASYONToolStripMenuItem.Click += new System.EventHandler(this.eRKENREZERVASYONToolStripMenuItem_Click);
            // 
            // pOPULERTATİLBÖLGELERİToolStripMenuItem
            // 
            this.pOPULERTATİLBÖLGELERİToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alanyaOtelleriToolStripMenuItem,
            this.çeşmeOtelleriToolStripMenuItem,
            this.kıbrısOToolStripMenuItem,
            this.uludağOtelleriToolStripMenuItem,
            this.sakaryaOtelleriToolStripMenuItem,
            this.kapadokyaOtelleriToolStripMenuItem,
            this.ayvalıkOtelleriToolStripMenuItem,
            this.kuşadasıOtelleriToolStripMenuItem});
            this.pOPULERTATİLBÖLGELERİToolStripMenuItem.Name = "pOPULERTATİLBÖLGELERİToolStripMenuItem";
            this.pOPULERTATİLBÖLGELERİToolStripMenuItem.Size = new System.Drawing.Size(160, 29);
            this.pOPULERTATİLBÖLGELERİToolStripMenuItem.Text = "POPULER TATİL BÖLGELERİ";
            // 
            // alanyaOtelleriToolStripMenuItem
            // 
            this.alanyaOtelleriToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.alanyaOtelleriToolStripMenuItem.Name = "alanyaOtelleriToolStripMenuItem";
            this.alanyaOtelleriToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.alanyaOtelleriToolStripMenuItem.Text = "Alanya Otelleri";
            this.alanyaOtelleriToolStripMenuItem.Click += new System.EventHandler(this.alanyaOtelleriToolStripMenuItem_Click);
            // 
            // çeşmeOtelleriToolStripMenuItem
            // 
            this.çeşmeOtelleriToolStripMenuItem.Name = "çeşmeOtelleriToolStripMenuItem";
            this.çeşmeOtelleriToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.çeşmeOtelleriToolStripMenuItem.Text = "Çeşme Otelleri";
            this.çeşmeOtelleriToolStripMenuItem.Click += new System.EventHandler(this.çeşmeOtelleriToolStripMenuItem_Click);
            // 
            // kıbrısOToolStripMenuItem
            // 
            this.kıbrısOToolStripMenuItem.Name = "kıbrısOToolStripMenuItem";
            this.kıbrısOToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.kıbrısOToolStripMenuItem.Text = "Kıbrıs Otelleri";
            this.kıbrısOToolStripMenuItem.Click += new System.EventHandler(this.kıbrısOToolStripMenuItem_Click);
            // 
            // uludağOtelleriToolStripMenuItem
            // 
            this.uludağOtelleriToolStripMenuItem.Name = "uludağOtelleriToolStripMenuItem";
            this.uludağOtelleriToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.uludağOtelleriToolStripMenuItem.Text = "Uludağ Otelleri";
            this.uludağOtelleriToolStripMenuItem.Click += new System.EventHandler(this.uludağOtelleriToolStripMenuItem_Click);
            // 
            // sakaryaOtelleriToolStripMenuItem
            // 
            this.sakaryaOtelleriToolStripMenuItem.Name = "sakaryaOtelleriToolStripMenuItem";
            this.sakaryaOtelleriToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.sakaryaOtelleriToolStripMenuItem.Text = "Sakarya Otelleri";
            this.sakaryaOtelleriToolStripMenuItem.Click += new System.EventHandler(this.sakaryaOtelleriToolStripMenuItem_Click);
            // 
            // kapadokyaOtelleriToolStripMenuItem
            // 
            this.kapadokyaOtelleriToolStripMenuItem.Name = "kapadokyaOtelleriToolStripMenuItem";
            this.kapadokyaOtelleriToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.kapadokyaOtelleriToolStripMenuItem.Text = "Kapadokya Otelleri";
            this.kapadokyaOtelleriToolStripMenuItem.Click += new System.EventHandler(this.kapadokyaOtelleriToolStripMenuItem_Click);
            // 
            // ayvalıkOtelleriToolStripMenuItem
            // 
            this.ayvalıkOtelleriToolStripMenuItem.Name = "ayvalıkOtelleriToolStripMenuItem";
            this.ayvalıkOtelleriToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.ayvalıkOtelleriToolStripMenuItem.Text = "Ayvalık Otelleri";
            this.ayvalıkOtelleriToolStripMenuItem.Click += new System.EventHandler(this.ayvalıkOtelleriToolStripMenuItem_Click);
            // 
            // kuşadasıOtelleriToolStripMenuItem
            // 
            this.kuşadasıOtelleriToolStripMenuItem.Name = "kuşadasıOtelleriToolStripMenuItem";
            this.kuşadasıOtelleriToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.kuşadasıOtelleriToolStripMenuItem.Text = "Kuşadası Otelleri";
            this.kuşadasıOtelleriToolStripMenuItem.Click += new System.EventHandler(this.kuşadasıOtelleriToolStripMenuItem_Click);
            // 
            // iLETİŞİMToolStripMenuItem
            // 
            this.iLETİŞİMToolStripMenuItem.Name = "iLETİŞİMToolStripMenuItem";
            this.iLETİŞİMToolStripMenuItem.Size = new System.Drawing.Size(63, 29);
            this.iLETİŞİMToolStripMenuItem.Text = "İLETİŞİM";
            this.iLETİŞİMToolStripMenuItem.Click += new System.EventHandler(this.iLETİŞİMToolStripMenuItem_Click);
            // 
            // gİRİŞToolStripMenuItem
            // 
            this.gİRİŞToolStripMenuItem.Name = "gİRİŞToolStripMenuItem";
            this.gİRİŞToolStripMenuItem.Size = new System.Drawing.Size(46, 29);
            this.gİRİŞToolStripMenuItem.Text = "GİRİŞ";
            this.gİRİŞToolStripMenuItem.Click += new System.EventHandler(this.gİRİŞToolStripMenuItem_Click);
            // 
            // bULToolStripMenuItem
            // 
            this.bULToolStripMenuItem.Name = "bULToolStripMenuItem";
            this.bULToolStripMenuItem.Size = new System.Drawing.Size(40, 29);
            this.bULToolStripMenuItem.Text = "BUL";
            this.bULToolStripMenuItem.Click += new System.EventHandler(this.bULToolStripMenuItem_Click);
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "Instagram_logo_2022.svg.png");
            this.ımageList1.Images.SetKeyName(1, "indir.png");
            this.ımageList1.Images.SetKeyName(2, "Facebook_icon.svg.png");
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Wheat;
            this.button3.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.button3.ImageKey = "Facebook_icon.svg.png";
            this.button3.ImageList = this.ımageList1;
            this.button3.Location = new System.Drawing.Point(838, 702);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(36, 34);
            this.button3.TabIndex = 5;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.button2.ImageKey = "indir.png";
            this.button2.ImageList = this.ımageList1;
            this.button2.Location = new System.Drawing.Point(796, 702);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(36, 35);
            this.button2.TabIndex = 4;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.AllowDrop = true;
            this.button1.BackColor = System.Drawing.Color.Wheat;
            this.button1.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.button1.ImageKey = "Instagram_logo_2022.svg.png";
            this.button1.ImageList = this.ımageList1;
            this.button1.Location = new System.Drawing.Point(754, 703);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(36, 34);
            this.button1.TabIndex = 3;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pictureBox1.Image = global::gorsel_final_odev.Properties.Resources.pexels_francesco_ungaro_96444__1_;
            this.pictureBox1.Location = new System.Drawing.Point(0, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(973, 739);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(96, 29);
            this.toolStripMenuItem1.Text = "ADMİN PANEL";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // anasayfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(973, 749);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.IsMdiContainer = true;
            this.Name = "anasayfa";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.anasayfa_FormClosing);
            this.Load += new System.EventHandler(this.anasayfa_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hAKKIMIZDAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pOPULEROTELLERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eRKENREZERVASYONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pOPULERTATİLBÖLGELERİToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alanyaOtelleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çeşmeOtelleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kıbrısOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uludağOtelleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sakaryaOtelleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kapadokyaOtelleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayvalıkOtelleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kuşadasıOtelleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iLETİŞİMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gİRİŞToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolStripMenuItem bULToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
    }
}