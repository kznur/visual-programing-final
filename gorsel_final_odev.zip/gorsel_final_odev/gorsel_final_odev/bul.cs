﻿using Guna.UI2.WinForms;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace gorsel_final_odev
{
    public partial class bul : Form
    {
        public bul()
        {
            InitializeComponent();
        }

        veritabani vt = new veritabani();
        private void guna2CustomGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        void bul_sehir()
        {
            guna2ComboBox1.Items.Clear();
            vt.mysqlbaglan.Open();
            MySqlCommand komut = new MySqlCommand("SELECT * FROM oteller1", vt.mysqlbaglan);
            MySqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                if(!guna2ComboBox1.Items.Contains(read["sehir"]) && read["sehir"]!="")
                      guna2ComboBox1.Items.Add(read["sehir"]);
            }
            vt.mysqlbaglan.Close();
            guna2ComboBox1.Text = guna2ComboBox1.Items[0].ToString();
        }
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {

        
                vt.mysqlbaglan.Open();
                MySqlCommand komut = new MySqlCommand("SELECT * FROM oteller1 where otelin_ismi='" + guna2ComboBox2.SelectedItem.ToString() + "'", vt.mysqlbaglan);
                MySqlDataReader read = komut.ExecuteReader();
                if (read.Read())
                {
                    bulgit bul_git = new bulgit();

                    bul_git.richTextBox1.Text = read["otelbilgileri"].ToString();
                    bul_git.label1.Text = read["otelin_ismi"].ToString();
                    bul_git.label4.Text = read["iki_kisilik_fiyat"].ToString();
                    bul_git.label5.Text = read["tek_kisilik_fiyat"].ToString();

                    bul_git.Show();
                }
                vt.mysqlbaglan.Close();


            

    


        }

        private void bul_Load(object sender, EventArgs e)
        {
            bul_sehir();
        }

        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            guna2ComboBox2.Items.Clear();
            vt.mysqlbaglan.Open();
            MySqlCommand komut = new MySqlCommand("SELECT * FROM oteller1 where sehir='" + guna2ComboBox1.SelectedItem.ToString() + "'", vt.mysqlbaglan);
            MySqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {

                guna2ComboBox2.Items.Add(read["otelin_ismi"]);
            }
            vt.mysqlbaglan.Close();
        
        }

        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
      
        }
    }
}
