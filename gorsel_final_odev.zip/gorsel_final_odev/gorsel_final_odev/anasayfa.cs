﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace gorsel_final_odev
{
    public partial class anasayfa : Form
    {
        public static anasayfa ana_sayfa;
        public bool is_admin = false;
        logo logo;
        public anasayfa(logo logo)
        {
            this.logo = logo;
            ana_sayfa = this;
            InitializeComponent();
        }

        public anasayfa()
        {
        }

        private void eRKENREZERVASYONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            siksorulan sorular=new siksorulan();
            sorular.Show();
        }

        private void gİRİŞToolStripMenuItem_Click(object sender, EventArgs e)
        {
            giris girissayfasi = new giris(this);
            girissayfasi.Show();
        }

        private void alanyaOtelleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        populer_tatil tatil=new populer_tatil(1);
            tatil.Show();
            tatil.pictureBox1.ImageLocation = "https://avatars.mds.yandex.net/i?id=289e8befc6137aa2e737a56fb911bfb861f7efd4-7950464-images-thumbs&n=13";
            tatil.pictureBox2.ImageLocation = "https://images.travel-cdn.com/image/upload/s--ZOXYIGMD--/c_limit,e_improve,fl_lossy.immutable_cache,h_940,q_auto:good,w_940/v1520534823/1e88d7b95b5fa48c253d74e1f3e2782aa4eb7e44";
            tatil.pictureBox3.ImageLocation = "https://avatars.mds.yandex.net/i?id=695020e77b12fc9b6686ce265ed7b2f3f2e0407f-7705680-images-thumbs&n=13";
            tatil.pictureBox4.ImageLocation = "https://avatars.mds.yandex.net/get-altay/1868686/2a0000016ab2309c9738708f1519d25cc063/XXL";
            tatil.pictureBox5.ImageLocation = "https://www.tatiltur.com/hotelphotosWebp/elisa-otel-genel-0014.webp";


        }

        private void anasayfa_Load(object sender, EventArgs e)
        {

        }

        private void çeşmeOtelleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            populer_tatil tatil2 = new populer_tatil(2);
            tatil2.Show();
            tatil2.pictureBox1.ImageLocation = "https://www.elcitur.com.tr/uploads/images/hotel/25/o_1csqnbibd8511q3cea3hjd1fnn7.jpg";
            tatil2.pictureBox2.ImageLocation = "https://pbs.twimg.com/media/D9RFW-CWwAAL0pr?format=jpg&name=4096x4096";
            tatil2.pictureBox3.ImageLocation = "https://www.tatilvitrini.com/uploads/images/hotel/16736/AIUBFI1573665731.jpg";
            tatil2.pictureBox4.ImageLocation = "https://www.gomutur.com/img/oteller/pictures/grannos_hotel_thermal_spa_6432__29_21_10_2016111200_b1_5f72e7725f73b.jpg";
            tatil2.pictureBox5.ImageLocation = "https://avatars.mds.yandex.net/get-altay/2051686/2a0000016fc42ce67121f7ab6f9ca50f0e71/XXL";

        }

        private void kıbrısOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            populer_tatil tatil3 = new populer_tatil(3);
            tatil3.Show();
            tatil3.pictureBox1.ImageLocation = "https://avatars.mds.yandex.net/i?id=89603b9560f4cd9ce29cd701f30e6d3326ccc9fe-5111908-images-thumbs&n=13";
            tatil3.pictureBox2.ImageLocation = "https://avatars.mds.yandex.net/i?id=2a00000179edb5fa1c2fc874b72c5460574e-4283943-images-thumbs&n=13";
            tatil3.pictureBox3.ImageLocation = "https://avatars.mds.yandex.net/i?id=24d8b24374104713e4e9ef62078e04976a9c6a8b-8357156-images-thumbs&n=13";
            tatil3.pictureBox4.ImageLocation = "https://avatars.mds.yandex.net/i?id=f6bbf5000ad8fc9c8a673c520c66f6fb7644bfa3-7014775-images-thumbs&n=13";
            tatil3.pictureBox5.ImageLocation = "https://avatars.mds.yandex.net/i?id=e69049317b6b4af37748bec631ebf38a-5666582-images-thumbs&n=13";

        }

        private void uludağOtelleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            populer_tatil tatil4 = new populer_tatil(4);
            tatil4.Show();
            tatil4.pictureBox1.ImageLocation = "https://www.gidiyoruz.com/wp-content/uploads/2018/10/Karinna-Hotel-Uluda%C4%9F-0021.jpg";
            tatil4.pictureBox2.ImageLocation = "https://panel.ecctur.com/uploads/hotel_12960/orginal/photo-12960-Ws04GeJCYLjt8aK.jpg";
            tatil4.pictureBox3.ImageLocation = "https://www.gidiyoruz.com/wp-content/uploads/2018/09/Uluda%C4%9F-Grand-Yaz%C4%B1c%C4%B1-Otel-0008.jpg";
            tatil4.pictureBox4.ImageLocation = "https://avatars.mds.yandex.net/i?id=3a1e67f7f1d85ee6a2947e0f035d4df38eaafbf0-5494287-images-thumbs&n=13";
            tatil4.pictureBox5.ImageLocation = "https://www.gidiyoruz.com/wp-content/uploads/2018/10/Erta-Soyak-Otel-Uluda%C4%9F-0004.jpg";

        }
   
           

        private void sakaryaOtelleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            populer_tatil tatil5 = new populer_tatil(5);
            tatil5.Show();
            tatil5.pictureBox1.ImageLocation = "https://avatars.mds.yandex.net/i?id=f674cb4379d1b66ff8f88c6a8c939d41-5473490-images-thumbs&n=13";
            tatil5.pictureBox2.ImageLocation = "https://iyifirma.com/resimler/6/sakarya-hotel-adapazari-80da0.jpg";
            tatil5.pictureBox3.ImageLocation = "https://gezilecekyerler.com/wp-content/uploads/2018/01/Sakarya-Otelleri-ve-Sakarya-Otel-Fiyatlar%C4%B1.jpg";
            tatil5.pictureBox4.ImageLocation = "https://lh3.googleusercontent.com/nJmIsIKK1v3nR46hPRfer2Ta22X1Od2T1hunkuinBbkRN1PNWO703XV5mVjEPUFRoOPeeY9LjPphn16pKFtuIZSrfT4=w1871-h2807-l70";
            tatil5.pictureBox5.ImageLocation = "https://cdn3.enuygun.com/media/lib/uploads/image/premier-inn-sakarya-sakarya-genel-36933888.jpg";
        }

        private void kapadokyaOtelleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            populer_tatil tatil7 = new populer_tatil(6);
            tatil7.Show();
            tatil7.pictureBox1.ImageLocation = "https://avatars.mds.yandex.net/i?id=21ac391846378702082338273d0427bd17ed0a3d-7765566-images-thumbs&n=13";
            tatil7.pictureBox2.ImageLocation = "https://i.pinimg.com/originals/c4/ea/dc/c4eadc907312664b636e0d42525c3f0c.jpg";
            tatil7.pictureBox3.ImageLocation = "https://www.jacadatravel.com/wp-content/uploads/2019/09/museum-hotel-cappadocia-exterior-at-night.jpg";
            tatil7.pictureBox4.ImageLocation = "https://storage.kucukoteller.com.tr/2018/12/04/1543908726407318.jpg";
            tatil7.pictureBox5.ImageLocation = "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/17/a3/71/30/carus-cappadocia.jpg?w=1200&h=-1&s=1";
        }

        private void ayvalıkOtelleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            populer_tatil tatil8 = new populer_tatil(7);
            tatil8.Show();
            tatil8.pictureBox1.ImageLocation = "https://www.otelfiyat.com/media/inet/1062205216/buyuk/YZWWQA1574853887.webp";
            tatil8.pictureBox2.ImageLocation = "https://gtr.tatilruyasi.com/UserFiles/Media/HotelImages/large/4041_CUNDA_ROTA_OTEL_41592.jpg";
            tatil8.pictureBox3.ImageLocation = "https://storage.kucukoteller.com.tr/2021/03/12/1615549420156781.jpg";
            tatil8.pictureBox4.ImageLocation = "https://panel.otelhatti.com/uploads/hotel_97/orginal/photo-97-FvWYAacDG792U8h.jpg";
            tatil8.pictureBox5.ImageLocation = "https://imgcy.trivago.com/c_fill,d_dummy.jpeg,e_sharpen:60,f_auto,h_627,q_auto,w_1200/itemimages/27/80/2780799_v1.jpeg";

        }

        private void kuşadasıOtelleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            populer_tatil tatil9 = new populer_tatil(8);
            tatil9.Show();
            tatil9.pictureBox1.ImageLocation = "https://tophotels.ru/icache/hotel_photos/83/103/5216/2568482_1600x1200.jpg";
            tatil9.pictureBox2.ImageLocation = "https://secreturkey.com/wp-content/uploads/2016/06/kusadasi-otelleri-2016-fiyatlari--1024x678.jpg";
            tatil9.pictureBox3.ImageLocation = "https://avatars.mds.yandex.net/i?id=bac218af429de3fa3445881bab2cc2e8-3727375-images-thumbs&n=13";
            tatil9.pictureBox4.ImageLocation = "https://i.neredekal.com/i/neredekal/75/1200x800/6024b117ff3ffdca374a3505";
            tatil9.pictureBox5.ImageLocation = "https://cdn.orsmod.com/userfiles/arorahotelkusadasi/arora-hotel-kusadasi-15569563316217.jpg";
        }

        private void bULToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bul bul_git = new bul();
            bul_git.Show();
        }

        private void anasayfa_FormClosing(object sender, FormClosingEventArgs e)
        {
            logo.Close();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void eRKENREZERVASYONToolStripMenuItem1_Click(object sender, EventArgs e)
        {
     
        }

        private void pOPULEROTELLERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hakkımızda hakkı_giris=new hakkımızda();
            hakkı_giris.Show();
        }

        private void hAKKIMIZDAToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void iLETİŞİMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            iletisim iletisim_giris = new iletisim();
            iletisim_giris.Show();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (is_admin)
            {
                adminpanel ad =  new adminpanel();
                ad.ShowDialog();
            }
            else
            {
                MessageBox.Show("admin değilsiniz!");
            }
        }
    }
}