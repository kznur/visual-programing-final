﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gorsel_final_odev
{
    public partial class bulgit : Form
    {
        public bulgit()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        veritabani vt = new veritabani();
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            vt.mysqlbaglan.Open();
            MySqlCommand cmd = new MySqlCommand("insert into rez (odel_id,kisi_sayisi) values('" + label1.Text + "','" + guna2ComboBox2.SelectedItem.ToString() + "')", vt.mysqlbaglan);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                MessageBox.Show("Rezerve Edilmiştir");
            }
            else
            {
                MessageBox.Show("Üzgünüz hata aldık.");

            }
            vt.mysqlbaglan.Close();
          
        }
    }
}
