﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace gorsel_final_odev
{
   
    public partial class giris : Form
    {
        anasayfa anasay=new anasayfa();
        

       
        public giris(anasayfa parametre)
        {
            InitializeComponent();
            anasay=parametre;
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            uyeol uyesayfasi=new uyeol();
            uyesayfasi.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            uyeol uyesayfasi = new uyeol();
            uyesayfasi.Show();
        }

        private void giris_Load(object sender, EventArgs e)
        {
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            veritabani vt = new veritabani();
            string ad = text1.Text;
            string sifre = text2.Text;
            MySqlCommand cmd = new MySqlCommand();
            vt.mysqlbaglan.Open();
            cmd.Connection = vt.mysqlbaglan;
            cmd.CommandText = "SELECT * FROM uyeler where kadi='" + text1.Text + "' AND sifre='" + text2.Text + "'";
            MySqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                int is_admin = (int)dr["is_admin"];
                if (is_admin == 1)
                {
                    anasayfa.ana_sayfa.is_admin = true;
                }
                anasay.Show();
                this.Close(); 
            }
            else
            {
                MessageBox.Show("Kullanıcı adı ya da şifre yanlış");
            }

            vt.mysqlbaglan.Close();
        }
    }
}
