﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gorsel_final_odev
{
    public partial class ek_sil_gün : Form
    {
        public ek_sil_gün()
        {
            InitializeComponent();
        }

        private void ek_sil_gün_Load(object sender, EventArgs e)
        {

        }
    }
}
