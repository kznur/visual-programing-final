﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace gorsel_final_odev
{
    public partial class populer_tatil : Form
    {
        int i;
        public populer_tatil(int i)
        {
            InitializeComponent();
            if (i == 1)
            {
                string sql = "SELECT * FROM `oteller1` WHERE otel_id = 1";
                string[][] veri = gh(sql);

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }


                // label1.Text = deger;
            }


            if (i == 2)
            {
                string sql = "SELECT * FROM `oteller1` WHERE otel_id = 2";
                string[][] veri = gh(sql);

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }


                // label1.Text = deger;
            }

            if (i == 3)
            {
                string sql = "SELECT * FROM `oteller1` WHERE otel_id = 3";
                string[][] veri = gh(sql);

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }


                // label1.Text = deger;
            }

            if (i == 4)
            {
                string sql = "SELECT * FROM `oteller1` WHERE otel_id = 4";
                string[][] veri = gh(sql);

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }


                // label1.Text = deger;
            }

            if (i == 5)
            {
                string sql = "SELECT * FROM `oteller1` WHERE otel_id = 5";
                string[][] veri = gh(sql);

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }


                // label1.Text = deger;
            }

            if (i == 6)
            {
                string sql = "SELECT * FROM `oteller1` WHERE otel_id = 6";
                string[][] veri = gh(sql);

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }


                // label1.Text = deger;
            }

            if (i == 7)
            {
                string sql = "SELECT * FROM `oteller1` WHERE otel_id = 7";
                string[][] veri = gh(sql);

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }


                // label1.Text = deger;
            }

            if (i == 8)
            {
                string sql = "SELECT * FROM `oteller1` WHERE otel_id = 8";
                string[][] veri = gh(sql);

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }

                for (int l = 0; l < veri.Length; l++)
                {
                    if (l == 0)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label1.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox1.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                label5.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                label4.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 1)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label6.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox2.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel16.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel14.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 2)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label7.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox3.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel18.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel17.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 3)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label8.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox4.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel20.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel19.Text = veri[l][j];
                            }
                        }

                    }
                    if (l == 4)
                    {
                        for (int j = 0; j < veri[l].Length; j++)
                        {
                            if (j == 1)
                            {
                                label9.Text = veri[l][j];
                            }
                            if (j == 3)
                            {
                                richTextBox5.Text = veri[l][j];
                            }
                            if (j == 4)
                            {
                                guna2HtmlLabel15.Text = veri[l][j];
                            }
                            if (j == 5)
                            {
                                guna2HtmlLabel13.Text = veri[l][j];
                            }
                        }

                    }


                }


                // label1.Text = deger;
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            /* switch (comboBox1.SelectedIndex)
             {
                 case 0:
                     guna2PictureBox1.ImageLocation = "C:\\resimler\\d2.jpg";
                     break;
                 case 1:
                     guna2PictureBox1.ImageLocation = "C:\\resimler\\d3.jpg";
                     break;
             }*/
            /*int secim = resimsec.SelectedIndex;
            switch (secim)
            {
                case 0:
                    guna2PictureBox1.Image = Image.FromFile("..\\..\\Resimler\\d2.jpg");
                    break;
                case 1:
                    guna2PictureBox2.Image = Image.FromFile("..\\..\\Resimler\\d3.jpg");
                    break;
                case 2:
                    guna2PictureBox3.Image = Image.FromFile("..\\..\\Resimler\\d4.jpg");
                    break;

            }*/
        }
        private void alanyaOtelleriToolStripMenuItem_Click(object sender, EventArgs e)
        {


        }


        veritabani vt = new veritabani();


        private string[][] gh(string sql)
        {
            string[][] result = new string[0][];

            try
            {
                vt.mysqlbaglan.Open();
                MySqlCommand commandDatabase = new MySqlCommand(sql, vt.mysqlbaglan);
                MySqlDataReader reader;
                int nrRanduri = 0;

                reader = commandDatabase.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        nrRanduri++;
                    }
                }
                reader.Close();

                if (nrRanduri > 0)
                {
                    reader = commandDatabase.ExecuteReader();
                    result = new string[nrRanduri][];
                    for (int i = 0; i < nrRanduri; i++)
                    {
                        result[i] = new string[reader.FieldCount];
                    }
                    if (reader.HasRows)
                    {
                        int i = 0;
                        while (reader.Read())
                        {
                            for (int j = 0; j < reader.FieldCount; j++)
                            {
                                result[i][j] = reader.GetString(j);
                            }
                            i++;
                        }
                    }
                }
                vt.mysqlbaglan.Close();

            }
            catch (Exception ex)
            {
                vt.mysqlbaglan.Close();
                MessageBox.Show(ex.Message);
            }

            return result;
        }


        private void populer_tatil_Load(object sender, EventArgs e)
        {
           for (int plh = 1; plh <= 8; plh++)
            {
                //guna2ComboBox1.Items.Add(plh.ToString());
            }
            /*
             resimsec.Items.Add("kedi1");
             resimsec.Items.Add("kedi2");
             resimsec.Items.Add("kedi3");*/
            



        }
       

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
