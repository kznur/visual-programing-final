﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gorsel_final_odev
{
    public partial class rezervasyon : Form
    {
        public static rezervasyon rx;
        public string odel_id;
        public int id;
        public rezervasyon()
        {
       
            InitializeComponent();
            rx = this;
        }

        veritabani vtn = new veritabani();
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            vtn.rex_ekle(odel_id, guna2ComboBox2.SelectedItem.ToString());
            odel_id = "";
            this.Close();
   
        }

        private void rezervasyon_Load(object sender, EventArgs e)
        {
            rx = this;
        }
    }
}
