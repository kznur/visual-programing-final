﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gorsel_final_odev
{
    public partial class adminpanel : Form
    {
        public adminpanel()
        {
            InitializeComponent();
            listView1.GridLines = true;
            listView1.AllowColumnReorder = true;
            listView1.LabelEdit = true;
            listView1.FullRowSelect = true;
            listView1.Sorting = SortOrder.Ascending;
            listView1.View = View.Details;

        }
        veritabani vtn= new veritabani();
        void listeleme()
        {
            try
            {
               vtn.mysqlbaglan.Open();
                string sql = "Select * from uyeler ";
                MySqlCommand cmd = new MySqlCommand(sql, vtn.mysqlbaglan);
                MySqlDataReader Reader = cmd.ExecuteReader();
                listView1.Items.Clear();
                while (Reader.Read())
                {
                    ListViewItem lv = new ListViewItem(Reader.GetInt32(0).ToString());
                    lv.SubItems.Add(Reader.GetString(1));
                  




                    lv.SubItems.Add(Reader.GetString(2));
                    lv.SubItems.Add(Reader.GetString(3));
                    lv.SubItems.Add(Reader.GetString(4));
                    lv.SubItems.Add(Reader.GetString(5));
                    lv.SubItems.Add(Reader.GetString(6));


                    listView1.Items.Add(lv);
                }
                Reader.Close();
                cmd.Dispose();
                vtn.mysqlbaglan.Close();


            }
            catch (Exception ex)
            {

            }
        }

    
        private void guna2VTrackBar1_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void guna2ToggleSwitch1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void adminpanel_Load(object sender, EventArgs e)
        {
            listeleme();
        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Right)
                {


                    if (listView1.FocusedItem.Bounds.Contains(e.Location) == true & listView1.FocusedItem.Bounds.Contains(e.Location) != null)
                    {
                        contextMenuStrip1.Show(Cursor.Position);
                    }
                }
            }
            catch
            {

            }
        }

        private void kullanıcıSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            vtn.mysqlbaglan.Open();
            string text = listView1.SelectedItems[0].Text;
            MySqlCommand cmd = new MySqlCommand("delete from uyeler where k_id='" + text + "'", vtn.mysqlbaglan);
            int x = cmd.ExecuteNonQuery();
            if (x == 1){
                listView1.Items.Clear();
                listView1.Clear();
                listeleme();
  
                MessageBox.Show("veri slindi");
            }
            else
            {
                MessageBox.Show("veri silinmedi");

            }
            vtn.mysqlbaglan.Close();

        }
    }
}
