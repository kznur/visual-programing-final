﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace gorsel_final_odev
{
    public partial class siksorulan : Form
    {
        public siksorulan()
        {
            InitializeComponent();
        }
        veritabani vt = new veritabani();

        private void siksorulan_Load(object sender, EventArgs e)
        {

            soru1();
            soru2();
            soru3();
            soru4();
            soru5();


        }
        void soru1()
        {

            vt.mysqlbaglan.Open();
            MySqlCommand komut = new MySqlCommand("SELECT * FROM sss where soru_id='1'", vt.mysqlbaglan);
            MySqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboBox1.Items.Add(read["cevap"]);
            }
            vt.mysqlbaglan.Close();
        }

        void soru2()
        {

            vt.mysqlbaglan.Open();
            MySqlCommand komut = new MySqlCommand("SELECT * FROM sss where soru_id='2'", vt.mysqlbaglan);
            MySqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboBox2.Items.Add(read["cevap"]);
            }
            vt.mysqlbaglan.Close();
        }

        void soru3()
        {

            vt.mysqlbaglan.Open();
            MySqlCommand komut = new MySqlCommand("SELECT * FROM sss where soru_id='3'", vt.mysqlbaglan);
            MySqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboBox3.Items.Add(read["cevap"]);
            }
            vt.mysqlbaglan.Close();
        }

        void soru4()
        {

            vt.mysqlbaglan.Open();
            MySqlCommand komut = new MySqlCommand("SELECT * FROM sss where soru_id='4'", vt.mysqlbaglan);
            MySqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboBox4.Items.Add(read["cevap"]);
            }
            vt.mysqlbaglan.Close();
        }

        void soru5()
        {

            vt.mysqlbaglan.Open();
            MySqlCommand komut = new MySqlCommand("SELECT * FROM sss where soru_id='5'", vt.mysqlbaglan);
            MySqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                comboBox5.Items.Add(read["cevap"]);
            }
            vt.mysqlbaglan.Close();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show(comboBox1.SelectedItem.ToString(),"Detaylı Bilgi");
        }
        private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            MessageBox.Show(comboBox2.SelectedItem.ToString(), "Detaylı Bilgi");
        }
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show(comboBox3.SelectedItem.ToString(), "Detaylı Bilgi");
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show(comboBox4.SelectedItem.ToString(), "Detaylı Bilgi");
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show(comboBox5.SelectedItem.ToString(), "Detaylı Bilgi");

        }

    
    }
}
